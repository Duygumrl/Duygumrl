package com.example.mobilodev;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActiviyt2  extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        ImageView gorsel1 = findViewById(R.id.görsel1);
        ImageView gorsel2 = findViewById(R.id.görsel2);
        ImageView gorsel3 = findViewById(R.id.görsel3);
        ImageView gorsel4 = findViewById(R.id.görsel4);



        gorsel1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActiviyt2.this, çileklipasta.class);
                startActivity(intent);
            }
        });

        gorsel2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActiviyt2.this, kuruvasan.class);
                startActivity(intent);
            }
        });

        gorsel3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActiviyt2.this, kurabiye.class);
                startActivity(intent);
            }
        });

        gorsel4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActiviyt2.this, tiramisu.class);
                startActivity(intent);
            }
        });


    }
}