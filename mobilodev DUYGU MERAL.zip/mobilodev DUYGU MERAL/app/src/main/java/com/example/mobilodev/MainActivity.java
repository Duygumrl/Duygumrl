package com.example.mobilodev;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button button1 = findViewById(R.id.button1);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MainActiviyt2.class);
                startActivity(intent);
            }

            @Override
            public void onClick(View v) {
                // İnternet Bağlantısını Kontrol Et

                if (NetworkUtil.isInternetAvailable(MainActivity.this)) {
                    Toast.makeText(MainActivity.this, "İnternet bağlantısı var!", Toast.LENGTH_SHORT).show();
                    // Burada diğer işlemler yapılabilir (örn: başka bir ekrana geçiş)
                } else {
                    Toast.makeText(MainActivity.this, "İnternet bağlantısı yok!", Toast.LENGTH_SHORT).show();
                }
            }

        });
        ImageView logo = findViewById(R.id.logo);
        Animation logoAnimation = AnimationUtils.loadAnimation(this, R.anim.animasyon);
        logo.startAnimation(logoAnimation);
    };
    }
